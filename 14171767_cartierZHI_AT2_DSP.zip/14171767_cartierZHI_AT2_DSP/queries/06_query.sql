select distinct category_name
		, price_range
		, sum(order_amount) over (partition by category_name, price_range) as total_amount
		, count(*) over (partition by category_name, price_range) as total_number_orders
from (select order_id
		, case 
				when od.unit_price < 20 then '1.Below $20'
				when od.unit_price >= 20 and od.unit_price <= 50 then '2. $20 - $50'
				when od.unit_price > 50 then '3. Over $50'
		end as price_range
		, cast(od.unit_price * quantity*(1-discount) as integer) as order_amount
		, product_name
		, category_id
		from order_details od
		full outer join products prod on od.product_id = prod.product_id) prod_od
full outer join categories cat on prod_od.category_id = cat.category_id 
order by category_name asc
		, price_range asc
;

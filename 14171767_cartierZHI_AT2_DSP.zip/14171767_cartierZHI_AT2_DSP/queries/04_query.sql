select *
from (select distinct substring(cast(order_date as varchar), 1, 8) || '01' as year_month
				, count(*) over (partition by substring(cast(order_date as varchar), 1, 8) || '01') as total_number_orders
				, cast((sum(freight) over (partition by substring(cast(order_date as varchar), 1, 8) || '01')) as integer) as total_freight
		from orders
		where substring(cast(order_date as varchar), 1, 8) like '1997%' 
			or substring(cast(order_date as varchar), 1, 8) like '1998%' 
		group by order_date
				, freight) query1
where total_number_orders > 35
order by total_freight desc
;


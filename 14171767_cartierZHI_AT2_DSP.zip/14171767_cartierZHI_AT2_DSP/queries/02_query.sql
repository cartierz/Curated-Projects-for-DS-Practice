select distinct ship_country
	, round(avg(extract(day from age(shipped_date, order_date))),2) as average_days_between_order_shipping
	, count(*) as total_number_orders
from orders
where extract(year from order_date) = 1998
group by ship_country
having avg(extract(day from age(shipped_date, order_date))) >= 5
	and count(*) > 10
order by ship_country asc
;

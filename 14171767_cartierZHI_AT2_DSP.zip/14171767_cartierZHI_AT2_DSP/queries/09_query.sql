select distinct employee_full_name
		, employee_title
		, total_sales_amount_excluding_discount
		, total_number_unique_orders
		, total_number_products
		, average_product_amount
		, round(cast(avg(total_sales_amount_excluding_discount/total_number_unique_orders) over 
			(partition by employee_full_name) as decimal), 2) as average_order_amount
		, total_discount_amount
		, total_sales_amount_including_discount
		, round(((total_sales_amount_excluding_discount-total_sales_amount_including_discount)/total_sales_amount_excluding_discount*100),2) as total_discount_percentage
from (select *
			, round(cast(sum(unit_price*quantity) over (partition by employee_full_name) as decimal), 2) as total_sales_amount_excluding_discount
			, dense_rank() over (partition by employee_full_name order by query1.order_id asc) + 
				 dense_rank() over (partition by employee_full_name order by query1.order_id desc) - 1 as total_number_unique_orders
			, sum(quantity) over (partition by employee_full_name) as total_number_products
			, round(cast(avg(unit_price) over (partition by employee_full_name) as decimal),2) as average_product_amount
			, round(cast(sum(discount) over (partition by employee_full_name) as decimal),2) as total_discount_amount
			, round(cast(sum(unit_price*quantity*(1-discount)) over (partition by employee_full_name) as decimal),2) as total_sales_amount_including_discount
		from (select *
					, first_name || ' ' || last_name as employee_full_name
					, title as employee_title
				from employees emp
				join orders ord on emp.employee_id = ord.employee_id) query1
		join order_details orddet on query1.order_id = orddet.order_id) query2
order by total_sales_amount_including_discount desc
;
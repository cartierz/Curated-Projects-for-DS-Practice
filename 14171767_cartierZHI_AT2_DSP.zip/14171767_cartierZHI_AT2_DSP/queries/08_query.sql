select category_name
		, product_name
		, unit_price
		, average_unit_price
		, round(cast(median_unit_price as decimal),2) as median_unit_price
	, case 
		when unit_price < average_unit_price then 'Below Average'
		when unit_price = average_unit_price then 'Equal Average'
		when unit_price > average_unit_price then 'Over Average'	
	end as average_unit_price_position
	, case 
		when unit_price < median_unit_price then 'Below Median'
		when unit_price = median_unit_price then 'Equal Median'
		when unit_price > median_unit_price then 'Over Median' 
	end as median_unit_price_position
from (select *
			, ((max(case when first_half = 1 then unit_price end) over (partition by category_id)) +
				(min(case when second_half = 1 then unit_price end) over (partition by category_id)))/2 as median_unit_price
		from (select product_name
						, unit_price
						, category_id
						, round(cast(avg(unit_price) over (partition by p.category_id) as decimal),2) as average_unit_price
						, ntile(2) over (partition by category_id order by unit_price) as first_half
						, ntile(2) over (partition by category_id order by unit_price desc) as second_half
				from products p
				where p.discontinued = 0) query1
				group by product_name
						, unit_price
						, category_id
						, average_unit_price
						, first_half
						, second_half) query2
join categories c on query2.category_id = c.category_id 
order by category_name asc
		, product_name asc
;




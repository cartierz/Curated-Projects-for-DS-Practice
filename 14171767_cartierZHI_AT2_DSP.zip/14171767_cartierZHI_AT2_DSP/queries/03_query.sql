select *
from (select emp.first_name ||  ' ' || emp.last_name as employee_full_name
			, emp.title as employee_title
			, age(emp.hire_date, emp.birth_date) as employee_age
			, mng.first_name ||  ' ' || mng.last_name as manager_full_name
			, mng.title as manager_title
	from employees emp
	full join employees mng on emp.reports_to = mng.employee_id) query3
where query3.employee_full_name is not null
order by query3.employee_age asc
		, employee_full_name asc
;
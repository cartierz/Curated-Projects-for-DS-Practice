select category_name
		, employee_full_name
		, total_sale_amount
		, round(cast(100*(total_sale_amount/(sum(total_sale_amount) over (partition by category_name))) as decimal), 2) as percent_of_employee_sales
		, round(cast(100*(total_sale_amount/(sum(total_sale_amount) over (partition by employee_full_name))) as decimal), 2) as percent_of_category_sales
from (select *
			, round(cast(sum(order_price) over (partition by category_name,  employee_full_name) as decimal),2) as total_sale_amount
		from (select *
					, query2.unit_price*quantity*(1-discount) as order_price
				from (select *
						from (select order_id
									, first_name || ' ' || last_name as employee_full_name
								from employees emp
								join orders ord on emp.employee_id = ord.employee_id) query1
						join order_details orddet on query1.order_id = orddet.order_id) query2 
				join products prod on query2.product_id = prod.product_id) query3
		join categories cat on query3.category_id = cat.category_id) query4
group by category_name
			, employee_full_name
			, total_sale_amount
order by category_name asc
			, total_sale_amount desc
;
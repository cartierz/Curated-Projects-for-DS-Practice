select product_name
		, unit_price
from products p 
where p.discontinued = 0 
		and p.unit_price between 20 and 50
order by p.unit_price desc
;

select prod.product_name
		, round(cast(prod.unit_price as decimal), 2) as current_price
		, round(cast(od.unit_price as decimal), 2) as previous_unit_price
		, cast((100*(prod.unit_price - od.unit_price)/od.unit_price) as integer) as percentage_increase
from products prod
full outer join order_details od on prod.product_id = od.product_id 
group by prod.product_name
		, prod.unit_price
		, od.unit_price
having cast((100*(prod.unit_price - od.unit_price)/od.unit_price) as integer) <= 20
	or cast((100*(prod.unit_price - od.unit_price)/od.unit_price) as integer) >= 30
	and count(od.product_id) > 10
order by percentage_increase asc
;



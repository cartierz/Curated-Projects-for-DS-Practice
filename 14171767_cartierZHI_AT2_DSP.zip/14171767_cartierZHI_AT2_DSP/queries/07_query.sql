select distinct category_name
		, supplier_region
		, sum(unit_in_stock) over (partition by  category_name, supplier_region) as unit_in_stock
		, sum(unit_on_order) over (partition by  category_name, supplier_region) as unit_on_order
		, sum(reorder_level) over (partition by  category_name, supplier_region) as reorder_level
from (select
		case 
			when country = 'Brazil' or country = 'Canada' or country = 'USA' then 'Americas'
			when country = 'Australia' or country = 'Japan' or country = 'Singapore' then 'Asia Pacific'
			else 'Europe'
		end as supplier_region
				, unit_in_stock
				, unit_on_order
				, reorder_level
				, category_id
		from suppliers sup
		full outer join products prod on sup.supplier_id = prod.supplier_id) sup_prod
full outer join categories cat on sup_prod.category_id = cat.category_id
order by category_name
		, supplier_region
		, reorder_level
;
